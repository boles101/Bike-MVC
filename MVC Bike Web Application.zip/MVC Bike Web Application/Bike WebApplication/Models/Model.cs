﻿using System.ComponentModel.DataAnnotations;
using System.Security.Permissions;

namespace Bike_WebApplication.Models
{
    public class Model
    {
        public int Id { get; set; }
        [MaxLength(255)]
        [Required]
        public string Name { get; set; }
        public Make make { get; set; }

        public  int MakeId { get; set; } 
    }
}
