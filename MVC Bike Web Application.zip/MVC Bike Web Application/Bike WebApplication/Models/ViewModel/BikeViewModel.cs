﻿using Microsoft.AspNetCore.Localization;
using System.Collections.Generic;

namespace Bike_WebApplication.Models.ViewModel
{
    public class BikeViewModel
    {
        public Bike Bike { get; set; }
        public IEnumerable<Make> Makes{ get; set; }
        public IEnumerable<Model> Models{ get; set; }
        public IEnumerable<Currency> Currencies{ get; set; }

        private List<Currency> Clist = new List<Currency>();

        private List<Currency> CreateList()
        {
            Clist.Add(new Currency("USD","USD"));
            Clist.Add(new Currency("EUR", "EUR"));
            Clist.Add(new Currency("EGP", "EGP"));

            return Clist;
        }

        public BikeViewModel()
        {
            Currencies = CreateList();
        }
    }

   

    public class Currency
    {
        public string Id{ get; set; }
        public string  Name { get; set; }
        public Currency(string id,string name)
        {
            Id = id;
            Name = name;
        }
    }
}
