﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections;
using System.Collections.Generic;

namespace Bike_WebApplication.Models.ViewModel
{
    public class ModelViewModel
    {
        public Model model { get; set; }
        public IEnumerable<Make> Makes { get; set; }

    }
}
