﻿namespace Bike_WebApplication.Helpers
{
    public class Roles
    {
        public const string Admin = "Admin";
        public const string Excutive= "Excutive";

    }
}
