﻿using Bike_WebApplication.Context;
using Bike_WebApplication.Helpers;
using Bike_WebApplication.Models.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Linq;

namespace Bike_WebApplication.Controllers
{
    [Authorize(Roles = Roles.Admin + "," + Roles.Excutive)]
    public class ModelController : Controller
    {
        private readonly BikeDbContext bikeDbContext;

        [BindProperty]
        public ModelViewModel modelView{ get; set; }

        public ModelController(BikeDbContext bikeDbContext)
        {
            this.bikeDbContext = bikeDbContext;
            modelView = new ModelViewModel()
            {
                Makes = bikeDbContext.Makes.ToList(),
                model = new Models.Model()

            };
        }
        public IActionResult Index()
        {
            var model = bikeDbContext.Models.Include(x => x.make);
            return View(model);
        }

        public IActionResult Create() 
        {
            return View(modelView);
        }
        [HttpPost,ActionName("Create")]
        public IActionResult CreatePost( )
        {
            if(ModelState.IsValid) 
            {
                bikeDbContext.Models.Add(modelView.model);
                bikeDbContext.SaveChanges();
                return RedirectToAction("Index");             

            }
            return View(modelView);
        }

        public IActionResult Edit(int id)
        {
            modelView.model = bikeDbContext.Models.Include(m => m.make).FirstOrDefault(m => m.Id == id);
            if (modelView.model == null)
                return NotFound();
            return View(modelView);
        }

        [HttpPost,ActionName("Edit")]
        public IActionResult EditPost(int id)
        {
            if (ModelState.IsValid)
            {
                bikeDbContext.Update(modelView.model);
                bikeDbContext.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(modelView);
        }

        public IActionResult Delete(int id)
        {
            var model = bikeDbContext.Models.Find(id);
            if(model == null)
                return NotFound();
            bikeDbContext.Models.Remove(model);
            bikeDbContext.SaveChanges();
            return RedirectToAction("Index");

        }

    }
}
