﻿using Bike_WebApplication.Context;
using Bike_WebApplication.Helpers;
using Bike_WebApplication.Models.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.IO;
using Microsoft.AspNetCore.Hosting;

namespace Bike_WebApplication.Controllers
{
    [Authorize(Roles = Roles.Admin + "," + Roles.Excutive)]
    public class BikeController : Controller
    {
        private readonly BikeDbContext bikeDbContext;
        private readonly IWebHostEnvironment hostingEnvironment;

        [BindProperty]
        public BikeViewModel BikeView { get; set; }

        public BikeController(BikeDbContext bikeDbContext ,IWebHostEnvironment hostingEnvironment)

        {
            this.bikeDbContext = bikeDbContext;
            this.hostingEnvironment = hostingEnvironment;
            this.hostingEnvironment = hostingEnvironment;
            BikeView = new BikeViewModel()
            {
                Makes = bikeDbContext.Makes.ToList(),
                Models = bikeDbContext.Models.ToList(),
                Bike = new Models.Bike(), 
                
            };
        }
        public IActionResult Index()
        {
            var Bikes = bikeDbContext.Bikes.Include(x => x.Make).Include(x=>x.Model);
            return View(Bikes.ToList()); ;
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View(BikeView);
        }

        [HttpPost, ActionName("Create")]
        [ValidateAntiForgeryToken]
        public IActionResult CreatePost()
        {
            if (ModelState.IsValid)
            {
                bikeDbContext.Bikes.Add(BikeView.Bike);
                bikeDbContext.SaveChanges();

                var BikeID = BikeView.Bike.Id;

                string wwrootpath = hostingEnvironment.WebRootPath;

                var files = HttpContext.Request.Form.Files;

                var SavedBike = bikeDbContext.Bikes.Find(BikeID);
                

                if(files.Count > 0) 
                {
                    var ImagePath = @"images";
                    var Extension = Path.GetExtension(files[0].FileName);
                    var RelativeImagePath = ImagePath+BikeID+Extension;
                    var AbsImagePath = Path.Combine(wwrootpath, RelativeImagePath);


                    using (var FileStream = new FileStream(AbsImagePath, FileMode.Create))
                    {
                        
                        files[0].CopyTo(FileStream);
                    }
                    SavedBike.ImagePath = RelativeImagePath;
                }
                else
                {
                    // If no image was uploaded, set the default image path
                    SavedBike.ImagePath = "~/images/images.png";
                    
                }
                    bikeDbContext.SaveChanges();
                return RedirectToAction("Index");

            }
            return View(BikeView);
        }

        //public IActionResult Edit(int id)
        //{
        //    modelView.model = bikeDbContext.Models.Include(m => m.make).FirstOrDefault(m => m.Id == id);
        //    if (modelView.model == null)
        //        return NotFound();
        //    return View(modelView);
        //}

        //[HttpPost, ActionName("Edit")]
        //public IActionResult EditPost(int id)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        bikeDbContext.Update(modelView.model);
        //        bikeDbContext.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    return View(modelView);
        //}

        public IActionResult Delete(int id)
        {
            var bike = bikeDbContext.Bikes.Find(id);
            if (bike == null)
                return NotFound();
            bikeDbContext.Bikes.Remove(bike);
            bikeDbContext.SaveChanges();
            return RedirectToAction("Index");

        }

    }
}
