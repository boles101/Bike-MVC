﻿using Bike_WebApplication.Context;
using Bike_WebApplication.Helpers;
using Bike_WebApplication.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace Bike_WebApplication.Controllers
{
    [Authorize(Roles = Roles.Admin + "," + Roles.Excutive)]
    public class MakeController : Controller
    {
        private readonly BikeDbContext bikeDbContext;

        public MakeController(BikeDbContext bikeDbContext)
        {
            this.bikeDbContext = bikeDbContext;
        }

        #region Index
        public IActionResult Index()
        {
            return View(bikeDbContext.Makes.ToList());
        }
        #endregion


        #region Create
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Make make)
        {
            if (ModelState.IsValid)
            {
                bikeDbContext.Add(make);
                bikeDbContext.SaveChanges();
            return RedirectToAction("Index");
            }
            return View(make);
        }
        #endregion

        #region Edit
        public IActionResult Edit(int id)
        {
                var make = bikeDbContext.Makes.Find(id);
                if (make != null)
                    return View(make);
                
                return NotFound();
        }

        [HttpPost]
        public IActionResult Edit(Make make)
        {
            if (ModelState.IsValid)
            {
                bikeDbContext.Update(make);
                bikeDbContext.SaveChanges();
                return RedirectToAction("Index");
            }
                return View(make);
        }
        #endregion

        #region Delete

        [HttpPost]
        public IActionResult Delete(int id)
        {
            var make = bikeDbContext.Makes.Find(id);
            if(make != null)
            {
                bikeDbContext.Remove(make);
                bikeDbContext.SaveChanges();
            }
            return RedirectToAction("Index");
        }


        #endregion
    }
}
