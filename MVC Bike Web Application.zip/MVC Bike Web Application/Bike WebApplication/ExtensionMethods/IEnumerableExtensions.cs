﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Linq;

namespace Bike_WebApplication.ExtensionMethods
{
    public static class IEnumerableExtensions
    {
        public static IEnumerable<SelectListItem> ToSelectListItem<T>(this IEnumerable<T> makes)
        {

            if (makes == null)
                return Enumerable.Empty<SelectListItem>();

            
            List<SelectListItem> Lists = new List<SelectListItem>();
            SelectListItem selectListItem = new SelectListItem()
            {
                Text = "----Select Item---",
                Value = "0"
            };
            Lists.Add(selectListItem);
            foreach (var item in makes)
            {
                selectListItem = new SelectListItem
                {
                    Text = item.GetPropertValue("Name"),
                    Value = item.GetPropertValue("Id")
                };
                Lists.Add(selectListItem);
            }
            return Lists;
        }


    }
}
