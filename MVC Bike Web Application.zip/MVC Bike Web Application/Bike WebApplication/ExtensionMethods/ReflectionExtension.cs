﻿namespace Bike_WebApplication.ExtensionMethods
{
    public static  class ReflectionExtension
    {
        public static string GetPropertValue<T>(this T item, string PropertyName)
        {
            return item.GetType().GetProperty(PropertyName).GetValue(item, null).ToString();
        }
    }
}
